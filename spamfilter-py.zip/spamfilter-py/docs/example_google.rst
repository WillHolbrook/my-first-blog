example\_google module
======================

.. automodule:: example_google
   :members:
   :undoc-members:
   :show-inheritance:
