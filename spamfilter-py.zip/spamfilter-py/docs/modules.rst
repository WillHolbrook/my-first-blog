spamfilter-py
=============

.. toctree::
   :maxdepth: 4

   example_google
